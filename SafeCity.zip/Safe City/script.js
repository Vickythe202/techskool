document.getElementById('loginForm').style.display = 'none';
